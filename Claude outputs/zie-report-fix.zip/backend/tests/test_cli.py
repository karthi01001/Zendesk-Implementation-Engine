from __future__ import annotations

from pathlib import Path

import pytest

from zie import cli


def test_parser_knows_the_phase_0_commands() -> None:
    parser = cli.build_parser()
    assert parser.parse_args(["serve", "--port", "9000"]).port == 9000
    assert parser.parse_args(["auth", "test"]).auth_command == "test"
    assert parser.parse_args(["snapshot", "groups", "--format", "json"]).format == "json"
    assert parser.parse_args(["snapshot"]).area is None
    assert parser.parse_args(["snapshot", "ticket-fields"]).area == "ticket-fields"


def test_missing_credentials_exit_cleanly(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str], tmp_path: object
) -> None:
    monkeypatch.chdir(str(tmp_path))
    monkeypatch.setattr(cli.AppState, "active_subdomain", property(lambda self: None))
    for key in ("ZIE_SUBDOMAIN", "ZIE_CLIENT_ID", "ZIE_CLIENT_SECRET"):
        monkeypatch.delenv(key, raising=False)
    assert cli.main(["auth", "test"]) == 1
    assert "No credentials found" in capsys.readouterr().err


def test_report_command_writes_word_and_html(tmp_path: Path) -> None:
    from tests.factories import make_snapshot, sample_instance
    from zie.snapshot import SnapshotStore

    store = SnapshotStore(tmp_path / "snapshots")
    store.save(make_snapshot(sample_instance()))
    path, seconds = cli.write_report(store, "acme", "docx", tmp_path / "report.docx")
    assert path.read_bytes()[:2] == b"PK" and seconds >= 0
    html, _ = cli.write_report(store, "acme", "html", tmp_path / "report.html")
    assert "Route shoe tickets" in html.read_text(encoding="utf-8")
    assert cli.build_parser().parse_args(["report", "--format", "html"]).format == "html"


def test_report_command_needs_a_saved_read(tmp_path: Path) -> None:
    from zie.snapshot import SnapshotStore

    with pytest.raises(cli.CliError, match="No saved read"):
        cli.write_report(SnapshotStore(tmp_path), "acme", "docx", None)
